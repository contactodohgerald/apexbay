<!DOCTYPE html>
<html lang="en">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
        <title>{{env('APP_NAME')}} - {{$pageName}}</title>
		
        <!-- All Plugins Css -->
        <link href="{{asset('assets/css/plugins.css')}}" rel="stylesheet">
		 

        <!-- Custom CSS -->
        <link href="{{asset('assets/css/styles.css')}}" rel="stylesheet">
    </head>