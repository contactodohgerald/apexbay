<div class="footer-wrapper">
    <div class="footer-section f-section-1">
        <p class="text-center">Copyright © <?php $d = date('Y'); print @$d; ?> {{env('APP_NAME')}}, All rights reserved.</p>
    </div>
</div>