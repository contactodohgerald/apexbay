<div class="card-body">
    <span class="font-bold text-primary p-l-20">SHARE:</span>
    <a href="https://twitter.com/share?url={{Request::url()}}" target="_blank">
        <button class="btn btn-secondary  m-l-40"><i class="fa fa-twitter"></i></button>
    </a>
    <a href="https://wa.me/+2347054349455?text={{Request::url()}}" target="_blank">
        <button class="btn btn-secondary"><i class="fa fa-whatsapp"></i></button>
    </a>
    <a href="https://www.facebook.com/sharer/sharer.php?u={{Request::url()}}" target="_blank">
        <button class="btn btn-secondary"><i class="fa fa-facebook-f"></i></button>
    </a>
</div>